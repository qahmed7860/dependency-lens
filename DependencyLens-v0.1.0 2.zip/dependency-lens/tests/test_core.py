import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError, URLError

from dependency_lens.cli import main
from dependency_lens.core import Dependency, Finding, Registry, analyze, compare, npm_key, report, scan


class DependencyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def write(self, name, content):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def dep(self, version="1.0.0", ecosystem="npm", declared=None):
        return Dependency(ecosystem, "sample", declared or version or ">=1", version, "package.json", "dependencies")

    def test_lock_and_dev(self):
        self.write("package.json", json.dumps({"dependencies": {"@scope/a": "^1.0.0"}, "devDependencies": {"test": "2.0.0"}}))
        self.write("package-lock.json", json.dumps({"packages": {"node_modules/@scope/a": {"version": "1.2.0"}}}))
        deps, warnings = scan(self.root)
        self.assertEqual(len(deps), 1)
        self.assertEqual(deps[0].current, "1.2.0")
        self.assertFalse(warnings)
        self.assertEqual(len(scan(self.root, include_dev=True)[0]), 2)

    def test_v1_lock(self):
        self.write("package.json", '{"dependencies":{"sample":"^1"}}')
        self.write("package-lock.json", '{"dependencies":{"sample":{"version":"1.3.0"}}}')
        self.assertEqual(scan(self.root)[0][0].current, "1.3.0")

    def test_python_requirements(self):
        self.write("requirements.txt", '# comment\nSample_Name[extra]==1.2.0 ; python_version>="3.11"\nother>=2 # note\n-r nested.txt\n')
        deps, warnings = scan(self.root)
        self.assertEqual(deps[0].name, "sample-name")
        self.assertEqual(deps[0].current, "1.2.0")
        self.assertIsNone(deps[1].current)
        self.assertEqual(len(warnings), 1)

    def test_pyproject_groups(self):
        self.write("pyproject.toml", '[project]\ndependencies=["sample==1.0"]\n[project.optional-dependencies]\ntest=["other>=2"]\n[dependency-groups]\ndev=["third==3.0", {include-group="test"}]\n')
        self.assertEqual(len(scan(self.root)[0]), 1)
        deps, warnings = scan(self.root, include_dev=True)
        self.assertEqual(len(deps), 3)
        self.assertEqual(len(warnings), 1)

    def test_recursive_excludes_and_symlinks(self):
        self.write("nested/requirements.txt", "sample==1")
        self.write("node_modules/pkg/requirements.txt", "hidden==1")
        (self.root / "linked").symlink_to(self.root / "nested", target_is_directory=True)
        self.assertEqual(len(scan(self.root, recursive=True)[0]), 1)
        self.assertEqual(scan(self.root)[0], [])

    def test_malformed_manifest_is_warning(self):
        self.write("package.json", "{")
        self.assertTrue(scan(self.root)[1])

    def test_lock_only_warns(self):
        self.write("package-lock.json", "{}")
        self.assertTrue(scan(self.root)[1])

    def test_comparison(self):
        for latest, status, upgrade in [("1.0.0", "current", None), ("1.0.1", "outdated", "patch"), ("1.1.0", "outdated", "minor"), ("2.0.0", "outdated", "major"), ("0.9.0", "ahead", None)]:
            with self.subTest(latest=latest):
                f = compare(self.dep(), latest)
                self.assertEqual((f.status, f.upgrade), (status, upgrade))

    def test_semver_precedence(self):
        versions = ["1.0.0-alpha", "1.0.0-alpha.1", "1.0.0-alpha.beta", "1.0.0-beta", "1.0.0-beta.2", "1.0.0-beta.11", "1.0.0-rc.1", "1.0.0"]
        self.assertEqual(sorted(versions, key=npm_key), versions)
        self.assertEqual(npm_key("1.0.0+build.5"), npm_key("1.0.0+build.9"))
        self.assertEqual(compare(self.dep("1.0.0-beta.2"), "1.0.0").upgrade, "release")
        self.assertEqual(compare(self.dep("01.0.0"), "1.0.0").status, "unknown")

    def test_pep440(self):
        self.assertEqual(compare(self.dep("1.0rc1", "pypi", "sample==1.0rc1"), "1.0").status, "outdated")
        self.assertEqual(compare(self.dep("1.0", "pypi", "sample==1.0"), "1.0.0").status, "current")

    def test_unpinned_and_unsupported(self):
        self.assertEqual(compare(self.dep(None), "2.0.0").status, "unpinned")
        self.assertEqual(compare(self.dep(None, declared="workspace:*"), None).status, "unsupported")
        self.assertEqual(compare(self.dep(None, "pypi", "sample @ https://example.com/a.whl"), None).status, "unsupported")

    def test_unique_lookup(self):
        registry = Registry(metadata={"npm:sample": "2.0.0"})
        with patch.object(registry, "latest", wraps=registry.latest) as mocked:
            self.assertEqual(len(analyze([self.dep(), self.dep()], registry)), 2)
            self.assertEqual(mocked.call_count, 1)

    def test_offline_never_networks(self):
        with patch("dependency_lens.core.urlopen", side_effect=AssertionError("network")):
            self.assertEqual(Registry(metadata={}).latest("npm", "sample")[0], None)
            self.assertEqual(Registry(metadata={"npm:sample": "2.0"}).latest("npm", "sample")[0], "2.0")

    def response(self, data):
        response = io.BytesIO(json.dumps(data).encode())
        return contextlib.closing(response)

    def test_pypi_filters_prerelease_yanked_empty(self):
        data = {"releases": {"1.0": [{"yanked": False}], "2.0": [{"yanked": True}], "3.0rc1": [{}], "4.0": [], "garbage": [{}]}}
        with patch("dependency_lens.core.urlopen", return_value=self.response(data)):
            self.assertEqual(Registry().latest("pypi", "sample"), ("1.0", ""))

    def test_npm_tag_and_scoped_encoding(self):
        with patch("dependency_lens.core.urlopen", return_value=self.response({"dist-tags": {"latest": "2.0.0"}})) as mock:
            self.assertEqual(Registry().latest("npm", "@scope/pkg")[0], "2.0.0")
            self.assertIn("%40scope%2Fpkg", mock.call_args.args[0].full_url)

    def test_registry_failures(self):
        for exc in [HTTPError("url", 404, "missing", {}, None), URLError("offline"), TimeoutError()]:
            with self.subTest(exc=exc), patch("dependency_lens.core.urlopen", side_effect=exc):
                self.assertIsNone(Registry().latest("npm", "sample")[0])

    def test_json_and_markdown(self):
        findings = [compare(self.dep(), "2.0.0")]
        self.assertEqual(json.loads(report(findings, [], "json"))["summary"], {"outdated": 1})
        findings[0].source = "a|b\nc"
        self.assertIn(r"a\|b c", report(findings, [], "markdown"))

    def test_cli_exit_and_output(self):
        self.write("requirements.txt", "sample==1.0")
        metadata = self.write("metadata.json", '{"pypi:sample":"2.0"}')
        output = self.root / "report.json"
        args = [str(self.root), "--metadata", str(metadata), "--format", "json", "--output", str(output)]
        self.assertEqual(main(args), 0)
        self.assertEqual(main(args + ["--fail-on-outdated"]), 1)
        self.assertEqual(json.loads(output.read_text())["dependencies"][0]["latest"], "2.0")

    def test_cli_incomplete_scan_fails(self):
        self.write("requirements.txt", "sample==1\n-r other.txt")
        meta = self.write("metadata.json", "{}")
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main([str(self.root), "--metadata", str(meta)]), 2)

    def test_bad_metadata_and_missing_path(self):
        bad = self.write("metadata.json", "[]")
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(main([str(self.root), "--metadata", str(bad)]), 2)
            self.assertEqual(main([str(self.root / "missing")]), 2)


if __name__ == "__main__":
    unittest.main()
