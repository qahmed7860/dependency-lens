"""DependencyLens: read-only dependency upgrade reports."""
__version__ = "0.1.0"
