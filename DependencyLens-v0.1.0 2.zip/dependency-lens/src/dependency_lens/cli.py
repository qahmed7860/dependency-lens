"""DependencyLens command-line interface."""
import argparse
import json
import math
from pathlib import Path
import sys

from . import __version__
from .core import Registry, analyze, report, scan


def main(argv=None):
    parser = argparse.ArgumentParser(description="Read-only Python and Node.js dependency upgrade reports.")
    parser.add_argument("path", nargs="?", default=".", type=Path, help="Project directory or supported manifest")
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--recursive", action="store_true", help="Scan nested projects; skip virtualenvs, build output and node_modules")
    parser.add_argument("--include-dev", action="store_true", help="Include npm dev/peer and Python optional/development groups")
    parser.add_argument("--format", choices=["terminal", "markdown", "json"], default="terminal")
    parser.add_argument("--output", type=Path, help="Write report to this file instead of stdout")
    parser.add_argument("--metadata", type=Path, help="Offline JSON map of registry:name to latest version (no network requests)")
    parser.add_argument("--timeout", type=float, default=10, help="Registry request timeout in seconds (default: 10)")
    parser.add_argument("--workers", type=int, default=8, help="Parallel registry requests, 1–32 (default: 8)")
    parser.add_argument("--fail-on-outdated", action="store_true", help="Exit 1 when any dependency is outdated")
    args = parser.parse_args(argv)
    if not math.isfinite(args.timeout) or args.timeout <= 0 or not 1 <= args.workers <= 32:
        parser.error("--timeout must be finite and positive; --workers must be between 1 and 32")
    try:
        metadata = None
        if args.metadata:
            metadata = json.loads(args.metadata.read_text(encoding="utf-8"))
            if not isinstance(metadata, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in metadata.items()):
                raise ValueError("Offline metadata must be an object mapping registry:name to version strings")
        dependencies, warnings = scan(args.path, args.recursive, args.include_dev)
        findings = analyze(dependencies, Registry(args.timeout, metadata), args.workers)
        text = report(findings, warnings, args.format)
        if args.output:
            args.output.write_text(text, encoding="utf-8")
        else:
            sys.stdout.write(text)
        # Errors take precedence over a CI outdated failure: incomplete scans never pass.
        if warnings or any(f.status in {"error", "unknown"} for f in findings):
            return 2
        return 1 if args.fail_on_outdated and any(f.status == "outdated" for f in findings) else 0
    except (OSError, ValueError) as exc:
        print(f"dependency-lens: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
