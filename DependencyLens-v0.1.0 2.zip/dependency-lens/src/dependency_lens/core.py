"""Manifest discovery, registry access, comparison and rendering.

No package installation or project code execution occurs during scanning.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
import re
import tomllib
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

from packaging.requirements import InvalidRequirement, Requirement
from packaging.utils import canonicalize_name
from packaging.version import InvalidVersion, Version

EXCLUDED = {"node_modules", ".git", ".venv", "venv", "__pycache__", "dist", "build"}
MANIFESTS = {"package.json", "package-lock.json", "requirements.txt", "pyproject.toml"}


@dataclass(frozen=True)
class Dependency:
    ecosystem: str
    name: str
    declared: str
    current: str | None
    source: str
    group: str


@dataclass
class Finding:
    ecosystem: str
    name: str
    declared: str
    current: str | None
    source: str
    group: str
    latest: str | None = None
    status: str = "unknown"
    upgrade: str | None = None
    note: str = ""


def exact_npm(value: str) -> str | None:
    return value if re.fullmatch(r"\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?", value) else None


def npm_key(value: str) -> tuple:
    """SemVer precedence, ignoring build metadata and comparing numeric prereleases numerically."""
    if not exact_npm(value):
        raise InvalidVersion(value)
    release, sep, prerelease = value.split("+", 1)[0].partition("-")
    parts = release.split(".")
    if any(len(p) > 1 and p.startswith("0") for p in parts):
        raise InvalidVersion(value)
    identifiers = prerelease.split(".") if sep else []
    if any(not p or (p.isdigit() and len(p) > 1 and p.startswith("0")) for p in identifiers):
        raise InvalidVersion(value)
    return (tuple(int(p) for p in parts), not bool(sep), tuple((0, int(p)) if p.isdigit() else (1, p) for p in identifiers))


def python_dependency(text: str, source: str, group: str) -> Dependency:
    req = Requirement(text)
    current = None
    specs = list(req.specifier)
    if len(specs) == 1 and specs[0].operator in {"==", "==="} and "*" not in specs[0].version:
        current = specs[0].version
    return Dependency("pypi", canonicalize_name(req.name), text, current, source, group)


def discover(root: Path, recursive: bool) -> list[Path]:
    if root.is_file():
        if root.name not in MANIFESTS:
            raise ValueError(f"Unsupported manifest: {root.name}")
        return [root]
    if not root.is_dir():
        raise ValueError(f"Path does not exist: {root}")
    found = []
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDED and not Path(directory, d).is_symlink())
        found.extend(Path(directory, f) for f in sorted(files) if f in MANIFESTS and not Path(directory, f).is_symlink())
        if not recursive:
            break
    return found


def scan(root: Path, recursive: bool = False, include_dev: bool = False) -> tuple[list[Dependency], list[str]]:
    paths = discover(root, recursive)
    dependencies, warnings = [], []
    if not paths:
        warnings.append("No supported manifests found.")
    for path in paths:
        source = str(path.relative_to(root)) if root.is_dir() else path.name
        try:
            if path.name == "package-lock.json":
                # package.json already consumes its adjacent lockfile; don't duplicate it.
                if path.with_name("package.json") in paths:
                    continue
                warnings.append(f"{source}: scan package.json alongside this lockfile to identify direct dependencies.")
                continue
            if path.name == "package.json":
                data = json.loads(path.read_text(encoding="utf-8"))
                lock = {}
                lockpath = path.with_name("package-lock.json")
                if lockpath.is_file():
                    try:
                        lock = json.loads(lockpath.read_text(encoding="utf-8"))
                    except (ValueError, OSError) as exc:
                        warnings.append(f"{source}: cannot read lockfile: {exc}")
                groups = ["dependencies", "optionalDependencies"] + (["devDependencies", "peerDependencies"] if include_dev else [])
                for group in groups:
                    for name, declared in sorted(data.get(group, {}).items()):
                        if not isinstance(declared, str):
                            raise ValueError(f"Invalid dependency specifier for {name}")
                        entry = lock.get("packages", {}).get(f"node_modules/{name}", {})
                        if not entry:
                            entry = lock.get("dependencies", {}).get(name, {})
                        current = entry.get("version") or exact_npm(declared)
                        dependencies.append(Dependency("npm", name, declared, current, source, group))
            elif path.name == "requirements.txt":
                for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                    line = re.split(r"\s+#", line, maxsplit=1)[0].strip()
                    if not line or line.startswith("#"):
                        continue
                    try:
                        dependencies.append(python_dependency(line, source, "dependencies"))
                    except InvalidRequirement:
                        warnings.append(f"{source}:{number}: unsupported requirement; includes, options and editable installs are not followed.")
            else:
                data = tomllib.loads(path.read_text(encoding="utf-8"))
                project = data.get("project", {})
                if "dependencies" in project.get("dynamic", []):
                    warnings.append(f"{source}: dynamic dependencies cannot be inspected statically.")
                for text in project.get("dependencies", []):
                    dependencies.append(python_dependency(text, source, "dependencies"))
                if include_dev:
                    for group, items in project.get("optional-dependencies", {}).items():
                        for text in items:
                            dependencies.append(python_dependency(text, source, f"optional:{group}"))
                    for group, items in data.get("dependency-groups", {}).items():
                        for text in items:
                            if isinstance(text, str):
                                dependencies.append(python_dependency(text, source, f"group:{group}"))
                            else:
                                warnings.append(f"{source}: dependency-group includes are not expanded.")
                if "tool" in data and "poetry" in data["tool"] and not project.get("dependencies"):
                    warnings.append(f"{source}: legacy Poetry dependency tables are not supported; use PEP 621 dependencies.")
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            warnings.append(f"{source}: {exc}")
    return dependencies, warnings


class Registry:
    """One request per unique package; fixture mode never uses the network."""

    def __init__(self, timeout: float = 10, metadata: dict | None = None):
        self.timeout = timeout
        self.metadata = metadata

    def latest(self, ecosystem: str, name: str) -> tuple[str | None, str]:
        if self.metadata is not None:
            value = self.metadata.get(f"{ecosystem}:{name}")
            if not isinstance(value, str):
                return None, "No release supplied in offline metadata."
            return value, "Offline fixture metadata."
        encoded = quote(name, safe="")
        url = f"https://pypi.org/pypi/{encoded}/json" if ecosystem == "pypi" else f"https://registry.npmjs.org/{encoded}"
        try:
            request = Request(url, headers={"Accept": "application/json", "User-Agent": "DependencyLens/0.1.0"})
            with urlopen(request, timeout=self.timeout) as response:
                payload = response.read(20_000_001)
                if len(payload) > 20_000_000:
                    return None, "Registry response exceeds 20 MB limit."
                data = json.loads(payload)
            if ecosystem == "npm":
                version = data.get("dist-tags", {}).get("latest")
                return (version, "") if isinstance(version, str) else (None, "Registry has no latest release tag.")
            versions = []
            for version, files in data.get("releases", {}).items():
                try:
                    parsed = Version(version)
                    if not parsed.is_prerelease and not parsed.is_devrelease and any(not f.get("yanked", False) for f in files):
                        versions.append((parsed, version))
                except InvalidVersion:
                    continue
            return (max(versions)[1], "") if versions else (None, "No stable, non-yanked release found.")
        except HTTPError as exc:
            return None, f"Registry returned HTTP {exc.code}."
        except (URLError, TimeoutError, OSError, ValueError, AttributeError, TypeError) as exc:
            return None, f"Registry lookup failed ({type(exc).__name__})."


def unsupported(dep: Dependency) -> bool:
    if dep.ecosystem == "pypi":
        return Requirement(dep.declared).url is not None
    return dep.declared.startswith(("file:", "link:", "workspace:", "git", "http:", "https:", "npm:")) or "/" in dep.declared


def compare(dep: Dependency, latest: str | None, note: str = "") -> Finding:
    result = Finding(**asdict(dep), latest=latest, note=note)
    if unsupported(dep):
        result.status, result.note = "unsupported", "Local, URL, Git, workspace and alias dependencies require manual review."
        return result
    if latest is None:
        result.status = "error"
        return result
    if dep.current is None:
        result.status = "unpinned"
        result.note = (note + " No exact or locked version; installed version is unknown.").strip()
        return result
    try:
        if dep.ecosystem == "npm":
            current, target = npm_key(dep.current), npm_key(latest)
            a, b = current[0], target[0]
        else:
            current, target = Version(dep.current), Version(latest)
            a = (current.release + (0, 0, 0))[:3]
            b = (target.release + (0, 0, 0))[:3]
        if current == target:
            result.status = "current"
        elif current > target:
            result.status = "ahead"
        else:
            result.status = "outdated"
            result.upgrade = "major" if a[0] != b[0] else "minor" if a[1] != b[1] else "patch" if a[2] != b[2] else "release"
    except InvalidVersion:
        result.status, result.note = "unknown", "Version could not be compared."
    return result


def analyze(dependencies: list[Dependency], registry: Registry, workers: int = 8) -> list[Finding]:
    keys = sorted({(d.ecosystem, d.name) for d in dependencies if not unsupported(d)})
    with ThreadPoolExecutor(max_workers=workers) as executor:
        values = list(executor.map(lambda key: registry.latest(*key), keys))
    resolved = dict(zip(keys, values))
    return [compare(d, *resolved.get((d.ecosystem, d.name), (None, ""))) for d in dependencies]


def report(findings: list[Finding], warnings: list[str], output_format: str) -> str:
    counts = {status: sum(f.status == status for f in findings) for status in sorted({f.status for f in findings})}
    if output_format == "json":
        return json.dumps({"schema_version": 1, "summary": counts, "warnings": warnings, "dependencies": [asdict(f) for f in findings]}, indent=2) + "\n"
    if output_format == "markdown":
        def cell(value):
            return str(value or "—").replace("|", "\\|").replace("\n", " ").replace("\r", " ")
        lines = ["# DependencyLens upgrade report", "", "Read-only comparison of direct dependencies. Latest releases may require changes to your declared constraints or runtime.", "", "| Package | Registry | Current | Latest | Status | Upgrade | Source / group |", "| --- | --- | --- | --- | --- | --- | --- |"]
        for f in findings:
            lines.append("| " + " | ".join(cell(v) for v in (f.name, f.ecosystem, f.current, f.latest, f.status, f.upgrade, f"{f.source} / {f.group}")) + " |")
        notes = [f"{f.name} ({f.source}): {f.note}" for f in findings if f.note]
        if warnings or notes:
            lines += ["", "## Notes", ""] + ["- " + cell(w) for w in warnings + notes]
    else:
        def clean(value):
            return re.sub(r"[\x00-\x1f\x7f]", "?", str(value))
        lines = ["DependencyLens · upgrade report", ""]
        for f in findings:
            lines.append(clean(f"{f.status.upper():11} {f.ecosystem}:{f.name}  {f.current or '(unpinned)'} → {f.latest or '?'}  {f.upgrade or ''}  [{f.source}; {f.group}]"))
            if f.note:
                lines.append("            " + clean(f.note))
        lines += ["", clean(f"{len(findings)} dependencies · " + ", ".join(f"{n} {s}" for s, n in counts.items()))]
        lines += ["Warning: " + clean(w) for w in warnings]
    return "\n".join(lines) + "\n"
