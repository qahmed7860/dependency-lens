# DependencyLens upgrade report

Read-only comparison of direct dependencies. Latest releases may require changes to your declared constraints or runtime.

| Package | Registry | Current | Latest | Status | Upgrade | Source / group |
| --- | --- | --- | --- | --- | --- | --- |
| example-utils | npm | 2.0.0 | 2.0.0 | current | — | package.json / dependencies |
| example-widget | npm | 1.2.0 | 2.0.0 | outdated | major | package.json / dependencies |
| example-test-runner | npm | 3.0.0 | 3.1.0 | outdated | minor | package.json / devDependencies |
| example-client | pypi | 1.0.0 | 1.1.0 | outdated | minor | requirements.txt / dependencies |
| example-api | pypi | — | 2.5.0 | unpinned | — | requirements.txt / dependencies |

## Notes

- example-utils (package.json): Offline fixture metadata.
- example-widget (package.json): Offline fixture metadata.
- example-test-runner (package.json): Offline fixture metadata.
- example-client (requirements.txt): Offline fixture metadata.
- example-api (requirements.txt): Offline fixture metadata. No exact or locked version; installed version is unknown.
